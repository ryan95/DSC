Configuration ADFS
{
    param ($MachineName)
    Node $MachineName
    {
        WindowsFeature ADFS {             
            Ensure = "Present"             
            Name   = "ADFS-Federation"           
        }
    }  
}