Configuration WAP
{
    param ($MachineName)
    Node $MachineName
    {
        WindowsFeature WAP {             
            Ensure = "Present"             
            Name   = "Web-Application-Proxy"           
        }
    }  
}