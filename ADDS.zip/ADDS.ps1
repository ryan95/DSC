Configuration DomainController
{

    Param ()

    Node local
    {
        WindowsFeature ADDomainServices          
        {             
            Ensure = "Present"             
            Name = "AD-Domain-Services"           
        }            
                     
        WindowsFeature RSATADDS            
        {             
            Ensure = "Present"             
            Name = "RSAT-ADDS"             
        } 
    
    }
}