Configuration NPS
{
    param ($MachineName)
    Node $MachineName
    {
        WindowsFeature NPS {             
            Ensure = "Present"             
            Name   = "NPAS"           
        }
    }  
}