Configuration SQLServer
{
    param ($MachineName)
    Import-DscResource -ModuleName StorageDsc
    Node $MachineName
    {
        WaitForDisk Disk2 {
            DiskId           = 2
            RetryIntervalSec = 60
            RetryCount       = 60
        }
        Disk LVolume {
            DiskId      = 2
            DriveLetter = 'L'
            FSLabel     = "Logs"
            DependsOn   = '[WaitForDisk]Disk2'
        }
        WaitForDisk Disk3 {
            DiskId           = 3
            RetryIntervalSec = 60
            RetryCount       = 60
        }
        Disk FVolume {
            DiskId      = 3
            DriveLetter = 'F'
            FSLabel     = "Data"
            DependsOn   = '[WaitForDisk]Disk3'
        }

    }
}