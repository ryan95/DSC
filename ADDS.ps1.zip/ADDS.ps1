Configuration DomainController
{

    Param ($MachineName)

    Node $MachineName
    {
        WindowsFeature ADDomainServices          
        {             
            Ensure = "Present"             
            Name = "AD-Domain-Services"           
        }            
                     
        WindowsFeature RSATADDS            
        {             
            Ensure = "Present"             
            Name = "RSAT-ADDS"             
        } 
    
    }
}