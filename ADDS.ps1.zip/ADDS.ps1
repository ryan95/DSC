$disk = Get-Disk | Where-Object partitionstyle -eq ‘raw’
Configuration DomainController
{
    param ($MachineName)
Import-DscResource -ModuleName StorageDsc
    Node $MachineName
    {
        WindowsFeature ADDomainServices          
        {             
            Ensure = "Present"             
            Name = "AD-Domain-Services"           
        }            
                     
        WindowsFeature RSATADDS            
        {             
            Ensure = "Present"             
            Name = "RSAT-ADDS"             
        }
        WaitForDisk Disk2
        {
             DiskId = $disk[0].UniqueId
             DiskIdType = 'UniqueId'
             RetryIntervalSec = 60
             RetryCount = 60
        }
        Disk DVolume
        {
            DiskId = $disk[0].UniqueId
            DiskIdType = 'UniqueId'
            DriveLetter = 'N'
            Size = 100GB
            DependsOn = '[WaitForDisk]Disk2' 
        }

          
            }
    }
