Configuration DomainController
{

    Param ($MachineName)

    Node $MachineName
    {
        WindowsFeature ADDomainServices          
        {             
            Ensure = "Present"             
            Name = "AD-Domain-Services"           
        }            
                     
        WindowsFeature RSATADDS            
        {             
            Ensure = "Present"             
            Name = "RSAT-ADDS"             
        } 
        Start-Transcript -Path C:\Temp\Diskinitlog.txt -Append -Force
 
        # Move CD-ROM drive to Z:
        "Moving CD-ROM drive to Z:.."
        Get-WmiObject -Class Win32_volume -Filter 'DriveType=5' | Select-Object -First 1 | Set-WmiInstance -Arguments @{DriveLetter='Z:'}
        # Set the parameters 
        $disks = Get-Disk | Where-Object partitionstyle -eq 'raw' | Sort-Object number
        $letters = 69..89 | ForEach-Object { [char]$_ }
        $count = 0
        $label = "Data"

        "Formatting disks.."
        foreach ($disk in $disks) {
        $driveLetter = $letters[$count].ToString()
       $disk |
        Initialize-Disk -PartitionStyle MBR -PassThru |
        New-Partition -UseMaximumSize -DriveLetter $driveLetter |
        Format-Volume -FileSystem NTFS -NewFileSystemLabel "$label.$count" -Confirm:$false -Force
        "$label.$count"
        $count++
    }
    }
}